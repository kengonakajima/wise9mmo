var hero : GameObject;




function Start () {
    hero = GameObject.Find( "HeroCube" );

/*
        transform.Translate(35,55,0);
        transform.LookAt( hero.transform.position );
*/
}



function Update () {
    //    var t:float = Time.realtimeSinceStartup;
    //    while(true){
    //        if( t < Time.realtimeSinceStartup - 0.5 )break;
    //    }
    

    
    var hs = hero.GetComponent("HeroScript");

        
        var dv = hs.nose - hero.transform.position;

        transform.position = hero.transform.position + Vector3(0,1,0) - dv.normalized*1;
        transform.LookAt( hs.nose );
/*
        var dscr = Input.GetAxis( "Mouse ScrollWheel" );
        transform.position += Vector3( 0, dscr*5, 0 );
        transform.LookAt( hs.nose );
*/
    
//    print( "fpsm:" + fpsMode + " campos:" + hero.transform.position.x + "," +hero.transform.position.y + " camnose:" + hs.nose + " campitch:" + hs.pitch );
    
}
