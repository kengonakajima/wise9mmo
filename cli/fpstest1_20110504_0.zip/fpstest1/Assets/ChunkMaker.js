// chunkのポリゴン生成するprefabにつける

var material:Material;

function makeCube( basepos : Vector3, vertices : Vector3[], uv : Vector2[], normals : Vector3[], vi : int, triangles : int[], ti : int )
{

    // uvが24個必要なので
    vertices[vi+0] = basepos + Vector3( 0,0,0 ); // Z=0 (0,1,2,3)
    vertices[vi+1] = basepos + Vector3( 1,0,0 ); //
    vertices[vi+2] = basepos + Vector3( 1,1,0 ); //
    vertices[vi+3] = basepos + Vector3( 0,1,0 ); //

    vertices[vi+4] = basepos + Vector3( 0,0,1 ); // Z=1  (4,5,6,7)
    vertices[vi+5] = basepos + Vector3( 1,0,1 ); //
    vertices[vi+6] = basepos + Vector3( 1,1,1 ); //
    vertices[vi+7] = basepos + Vector3( 0,1,1 ); //
    
    vertices[vi+8] = basepos + Vector3( 0,0,0 ); // X=0 (0,4,7,3)
    vertices[vi+9] = basepos + Vector3( 0,0,1 ); //
    vertices[vi+10] = basepos + Vector3( 0,1,1 ); //
    vertices[vi+11] = basepos + Vector3( 0,1,0 ); //
    
    vertices[vi+12] = basepos + Vector3( 1,0,0 ); // X=1 (1,5,6,2)
    vertices[vi+13] = basepos + Vector3( 1,0,1 ); //
    vertices[vi+14] = basepos + Vector3( 1,1,1 ); //
    vertices[vi+15] = basepos + Vector3( 1,1,0 ); //

    vertices[vi+16] = basepos + Vector3( 0,0,0 ); // Y=0 (0,1,5,4)
    vertices[vi+17] = basepos + Vector3( 1,0,0 ); //
    vertices[vi+18] = basepos + Vector3( 1,0,1 ); //
    vertices[vi+19] = basepos + Vector3( 0,0,1 ); //

    vertices[vi+20] = basepos + Vector3( 0,1,0 ); // Y=1 (3,2,6,7)
    vertices[vi+21] = basepos + Vector3( 1,1,0 ); //
    vertices[vi+22] = basepos + Vector3( 1,1,1 ); //
    vertices[vi+23] = basepos + Vector3( 0,1,1 ); //
    

    // 画像の左下がuv=0, 右上がuv=1
    var m = 1;
    uv[vi+0] = Vector2(0,0); // Z=0
    uv[vi+1] = Vector2(m,0);
    uv[vi+2] = Vector2(m,m);
    uv[vi+3] = Vector2(0,m);

    uv[vi+4] = Vector2(m,0); // Z=1
    uv[vi+5] = Vector2(0,0);
    uv[vi+6] = Vector2(0,m);
    uv[vi+7] = Vector2(m,m);

    uv[vi+8] = Vector2(m,0); // X=0
    uv[vi+9] = Vector2(0,0);
    uv[vi+10] = Vector2(0,m);
    uv[vi+11] = Vector2(m,m);

    uv[vi+12] = Vector2(0,0); // X=1
    uv[vi+13] = Vector2(m,0);
    uv[vi+14] = Vector2(m,m);
    uv[vi+15] = Vector2(0,m);

    uv[vi+16] = Vector2(0,m); // Y=0
    uv[vi+17] = Vector2(m,m);
    uv[vi+18] = Vector2(m,0);
    uv[vi+19] = Vector2(0,0);

    uv[vi+20] = Vector2(0,0); // Y=1
    uv[vi+21] = Vector2(m,0);
    uv[vi+22] = Vector2(m,m);
    uv[vi+23] = Vector2(0,m);        
    
    // 明るさを決めるための法線
    var l = 0;  // 0にしたら一番暗く、１にしたらあかるいが、0.4でほぼ最高. ここをそれぞれ異なる値にしたら、角の奥は暗いとか簡単にできる
    normals[vi+0] = Vector3(0,l,0); // Z=0 
    normals[vi+1] = Vector3(0,l,0); 
    normals[vi+2] = Vector3(0,l,0); 
    normals[vi+3] = Vector3(0,l,0);

    normals[vi+4] = Vector3(0,l,0); // Z=1
    normals[vi+5] = Vector3(0,l,0);
    normals[vi+6] = Vector3(0,l,0);
    normals[vi+7] = Vector3(0,l,0);

    normals[vi+8] = Vector3(0,l,0); // X=0
    normals[vi+9] = Vector3(0,l,0);
    normals[vi+10] = Vector3(0,l,0);
    normals[vi+11] = Vector3(0,l,0);    
    
    normals[vi+12] = Vector3(0,l,0); // X=1
    normals[vi+13] = Vector3(0,l,0);
    normals[vi+14] = Vector3(0,l,0);
    normals[vi+15] = Vector3(0,l,0);

    normals[vi+16] = Vector3(0,l,0); // Y=0
    normals[vi+17] = Vector3(0,l,0);
    normals[vi+18] = Vector3(0,l,0);
    normals[vi+19] = Vector3(0,l,0);
    
    normals[vi+20] = Vector3(0,l,0); // Y=1
    normals[vi+21] = Vector3(0,l,0);
    normals[vi+22] = Vector3(0,l,0);
    normals[vi+23] = Vector3(0,l,0);
    
    triangles[ti+0] = vi+0; // z=0平面の２つの三角
    triangles[ti+1] = vi+2;
    triangles[ti+2] = vi+1;
    triangles[ti+3] = vi+0;
    triangles[ti+4] = vi+3;
    triangles[ti+5] = vi+2;

    triangles[ti+6] = vi+4; // z=1平面の２つの三角
    triangles[ti+7] = vi+5;
    triangles[ti+8] = vi+6;
    triangles[ti+9] = vi+4;
    triangles[ti+10] = vi+6;
    triangles[ti+11] = vi+7;

    triangles[ti+12] = vi+8; // x=0
    triangles[ti+13] = vi+9;
    triangles[ti+14] = vi+10;
    triangles[ti+15] = vi+8;
    triangles[ti+16] = vi+10;
    triangles[ti+17] = vi+11;
    
    triangles[ti+18] = vi+12; // x=1
    triangles[ti+19] = vi+14;
    triangles[ti+20] = vi+13;
    triangles[ti+21] = vi+12;
    triangles[ti+22] = vi+15;
    triangles[ti+23] = vi+14;

    triangles[ti+24] = vi+16; // y=0
    triangles[ti+25] = vi+17;
    triangles[ti+26] = vi+18;
    triangles[ti+27] = vi+16;
    triangles[ti+28] = vi+18;
    triangles[ti+29] = vi+19;
    
    triangles[ti+30] = vi+20; // y=1
    triangles[ti+31] = vi+22;
    triangles[ti+32] = vi+21;
    triangles[ti+33] = vi+20;
    triangles[ti+34] = vi+23;
    triangles[ti+35] = vi+22;
    
    /*
    //必要な頂点は
    vertices[vi+0] = basepos + Vector3( 0,0,0 ); // Z=0
    vertices[vi+1] = basepos + Vector3( 0,1,0 ); //
    vertices[vi+2] = basepos + Vector3( 1,0,0 ); //
    vertices[vi+3] = basepos + Vector3( 1,1,0 ); //

    vertices[vi+4] = basepos + Vector3( 0,0,1 ); // Z=1
    vertices[vi+5] = basepos + Vector3( 0,1,1 ); //    
    vertices[vi+6] = basepos + Vector3( 1,0,1 ); //
    vertices[vi+7] = basepos + Vector3( 1,1,1 ); //    

    // uv
    uv[vi+0] = Vector2(0,0); // Z=0
    uv[vi+1] = Vector2(0,1);
    uv[vi+2] = Vector2(1,0);
    uv[vi+3] = Vector2(1,1);

    uv[vi+4] = Vector2(1,1); // Z=1
    uv[vi+5] = Vector2(1,0);
    uv[vi+6] = Vector2(0,0);
    uv[vi+7] = Vector2(0,1);

    triangles[ti+0] = vi+0; // Z=0平面の三角0
    triangles[ti+1] = vi+1; // 
    triangles[ti+2] = vi+2; //
    triangles[ti+3] = vi+1; // Z=0平面の三角1
    triangles[ti+4] = vi+3; // 
    triangles[ti+5] = vi+2; //

    triangles[ti+6] = vi+4; // Z=1平面の三角0
    triangles[ti+7] = vi+6;
    triangles[ti+8] = vi+5;
    triangles[ti+9] = vi+5; // Z=1平面の三角1
    triangles[ti+10]= vi+6;
    triangles[ti+11]= vi+7;

    triangles[ti+12] = vi+5; // X=0平面の三角0
    triangles[ti+13] = vi+1;
    triangles[ti+14] = vi+0;
    triangles[ti+15] = vi+0; // X=0平面の三角1
    triangles[ti+16] = vi+4;
    triangles[ti+17] = vi+5;

    triangles[ti+18] = vi+2; // X=1平面の三角0
    triangles[ti+19] = vi+3;
    triangles[ti+20] = vi+6;
    triangles[ti+21] = vi+3; // X=1平面の三角1
    triangles[ti+22] = vi+7;
    triangles[ti+23] = vi+6;

    triangles[ti+24] = vi+0; // Y=0平面の三角0
    triangles[ti+25] = vi+2;
    triangles[ti+26] = vi+6;
    triangles[ti+27] = vi+0; // Y=1平面の三角1
    triangles[ti+28] = vi+6;
    triangles[ti+29] = vi+4;

    triangles[ti+30] = vi+1; // Y=1平面の三角0
    triangles[ti+31] = vi+5;
    triangles[ti+32] = vi+3;
    triangles[ti+33] = vi+5; // Y=1平面の三角1
    triangles[ti+34] = vi+7;
    triangles[ti+35] = vi+3;
*/
}


function Start() {
    print("chunkmaker start");

	if (material)
		renderer.material = material;
	else
		renderer.material.color = Color.white;

	var mesh : Mesh = GetComponent(MeshFilter).mesh;

    mesh.Clear();


    var n:int = 4;
    var vertices : Vector3[] = new Vector3[ n*n*n *24 ];
    var uv : Vector2[] = new Vector2[ n*n*n *24 ];
    var triangles : int[] = new int[ n*n*n * 36 ];
    var normals : Vector3[] = new Vector3[n*n*n*24]; // 頂点数と同じだけ必要
    
    var vi:int=0;
    var ti:int=0;
    
    for( var z:int = 0; z < n; z++ ){
        for( var y:int = 0; y < n; y++ ){
            for( var x:int = 0; x < n; x++ ){
                // makeCube( Vector3(x*1.3,y*1.3,z*1.3));
                makeCube( Vector3(x*1.3,y*1.3,z*1.3 ),
                          vertices,
                          uv,
                          normals,
                          vi,
                          triangles,
                          ti );
                vi += 24;
                ti += 36;
            }
        }
    }
    
    mesh.vertices = vertices;
    mesh.uv = uv;
    mesh.triangles = triangles;
    mesh.normals = normals;
    //mesh.RecalculateNormals();
    
}

function Update() {
}
