// chunkのポリゴン生成するprefabにつける

var material:Material;

var objmode:int; // 


var REDFLOWER=100;
var BLUEFLOWER=101;

// atlasIndexから [startU, startV, endU, endV]もとめる
function calcUVs( i:int ) {
    var out :float[] = new float[4];
    
    // atlas中の座標求める
    var wi:int = ( 512/16 );
    var atlasCol:int = i % wi;
    var atlasRow:int = i / wi;
    var unit:float = 1.0 / wi;

    var ep:float = 0.001;
    out[0] = atlasCol*unit+ep;
    out[1] = 1.0 - atlasRow*unit - unit + ep;
    out[2] = out[0] + unit - ep-ep;
    out[3] = out[1] + unit - ep-ep;    
    
    return out;    
}

function lightIndexToNormal(i:int){
    if( i==0){
        return 0.05;
    } else {
        return 0.05 + ( ((i-1)*1.0) / 8.0 );
    }
}

// 花の形状をつくる
function makeFlowerObj( basepos : Vector3, vertices : Vector3[], uv : Vector2[], normals : Vector3[], vi : int, triangles : int[], ti : int, objType :int , light:int )
{
    // Z=0.5
    vertices[vi+0] = basepos+Vector3( 0,0,0.5 ); // z=0.5の面(裏表共用)
    vertices[vi+1] = basepos+Vector3( 1,0,0.5 );
    vertices[vi+2] = basepos+Vector3( 1,1,0.5 );
    vertices[vi+3] = basepos+Vector3( 0,1,0.5 );

    vertices[vi+4] = basepos+Vector3( 0.5,0,0 ); // x=0.5の面(裏表共用)
    vertices[vi+5] = basepos+Vector3( 0.5,0,1 );
    vertices[vi+6] = basepos+Vector3( 0.5,1,1 );
    vertices[vi+7] = basepos+Vector3( 0.5,1,0 );

    var uvs:float[];
    if(objType==REDFLOWER){
        uvs = calcUVs( 256 );
    } else if( objType==BLUEFLOWER){
        uvs = calcUVs( 257 );
    } else{
        throw "bug";
    }

    //    print( "u:"+uStart + " v:" + vStart + " col:"+atlasCol + " row:"+atlasRow );
    uv[vi+0] = Vector2(uvs[0],uvs[1]);
    uv[vi+1] = Vector2(uvs[2],uvs[1]);
    uv[vi+2] = Vector2(uvs[2],uvs[3]);
    uv[vi+3] = Vector2(uvs[0],uvs[3]);

    uv[vi+4] = uv[vi+0];
    uv[vi+5] = uv[vi+1];
    uv[vi+6] = uv[vi+2];
    uv[vi+7] = uv[vi+3];

    var l = lightIndexToNormal(light);
    normals[vi+0]=normals[vi+1]=normals[vi+2]=normals[vi+3]=normals[vi+4]=normals[vi+5]=normals[vi+6]=normals[vi+7]=Vector3(0,l,0);

    triangles[ti+0] = vi+0; // z=0.5 表
    triangles[ti+1] = vi+2;
    triangles[ti+2] = vi+1;
    triangles[ti+3] = vi+0;
    triangles[ti+4] = vi+3;
    triangles[ti+5] = vi+2;

    triangles[ti+6] = vi+0; // z=0.5 裏
    triangles[ti+7] = vi+1;
    triangles[ti+8] = vi+2;
    triangles[ti+9] = vi+0;
    triangles[ti+10] = vi+2;
    triangles[ti+11] = vi+3;

    triangles[ti+12] = vi+4; // x=0.5表(X+)
    triangles[ti+13] = vi+6;
    triangles[ti+14] = vi+5;
    triangles[ti+15] = vi+4;
    triangles[ti+16] = vi+7;
    triangles[ti+17] = vi+6;

    triangles[ti+18] = vi+4;
    triangles[ti+19] = vi+5;
    triangles[ti+20] = vi+6;    
    triangles[ti+21] = vi+4;
    triangles[ti+22] = vi+6;
    triangles[ti+23] = vi+7;        
    
}

    
// lights: z0z1x0x1y0y1の順で、各面を照らす明るさ
function makeCube( basepos : Vector3, vertices : Vector3[], uv : Vector2[], normals : Vector3[], vi : int, triangles : int[], ti : int, blockType :int , lights:int[], drawflags:int[] )
{
    var curvi = vi;
    var curti = ti;

    var startvis:int[]=new int[6];
    var starttis:int[]=new int[6];

    for(var i:int=0;i<6;i++){
        if( drawflags[i] ){
            startvis[i]=curvi;
            starttis[i]=curti;
            curvi += 4;
            curti += 2*3;
        }
    }
        
    // uvが24個必要なので
    if( drawflags[0] ){
        vi=startvis[0];
        vertices[vi+0] = basepos + Vector3( 0,0,0 ); // Z=0 (0,1,2,3)
        vertices[vi+1] = basepos + Vector3( 1,0,0 ); //
        vertices[vi+2] = basepos + Vector3( 1,1,0 ); //
        vertices[vi+3] = basepos + Vector3( 0,1,0 ); //
    }
    if( drawflags[1] ){
        vi=startvis[1];
        vertices[vi+0] = basepos + Vector3( 0,0,1 ); // Z=1  (4,5,6,7)
        vertices[vi+1] = basepos + Vector3( 1,0,1 ); //
        vertices[vi+2] = basepos + Vector3( 1,1,1 ); //
        vertices[vi+3] = basepos + Vector3( 0,1,1 ); //
    }
    if( drawflags[2] ){
        vi=startvis[2];
        vertices[vi+0] = basepos + Vector3( 0,0,0 ); // X=0 (0,4,7,3)
        vertices[vi+1] = basepos + Vector3( 0,0,1 ); //
        vertices[vi+2] = basepos + Vector3( 0,1,1 ); //
        vertices[vi+3] = basepos + Vector3( 0,1,0 ); //
    }
    if( drawflags[3] ){
        vi=startvis[3];
        vertices[vi+0] = basepos + Vector3( 1,0,0 ); // X=1 (1,5,6,2)
        vertices[vi+1] = basepos + Vector3( 1,0,1 ); //
        vertices[vi+2] = basepos + Vector3( 1,1,1 ); //
        vertices[vi+3] = basepos + Vector3( 1,1,0 ); //
    }
    if( drawflags[4] ){
        vi=startvis[4];
        vertices[vi+0] = basepos + Vector3( 0,0,0 ); // Y=0 (0,1,5,4)
        vertices[vi+1] = basepos + Vector3( 1,0,0 ); //
        vertices[vi+2] = basepos + Vector3( 1,0,1 ); //
        vertices[vi+3] = basepos + Vector3( 0,0,1 ); //
    }
    if( drawflags[5] ){
        vi=startvis[5];
        vertices[vi+0] = basepos + Vector3( 0,1,0 ); // Y=1 (3,2,6,7)
        vertices[vi+1] = basepos + Vector3( 1,1,0 ); //
        vertices[vi+2] = basepos + Vector3( 1,1,1 ); //
        vertices[vi+3] = basepos + Vector3( 0,1,1 ); //
    }
    

    // 画像の左下がuv=0, 右上がuv=1
    var su:float;
    var sv:float;
    var eu:float;
    var ev:float;

    // atlas中の座標求める
    var uvs:float[] = calcUVs( blockType + (512/16) );
    su = uvs[0];sv = uvs[1];eu = uvs[2];ev = uvs[3];

    if(drawflags[0]){
        vi=startvis[0];
        uv[vi+0] = Vector2(su,sv); // Z=0 横面
        uv[vi+1] = Vector2(eu,sv);
        uv[vi+2] = Vector2(eu,ev);
        uv[vi+3] = Vector2(su,ev);
    }
    if( drawflags[1]){
        vi=startvis[1];
        uv[vi+0] = Vector2(eu,sv); // Z=1 横面
        uv[vi+1] = Vector2(su,sv);
        uv[vi+2] = Vector2(su,ev);
        uv[vi+3] = Vector2(eu,ev);
    }
    if( drawflags[2]){
        vi=startvis[2];
        uv[vi+0] = Vector2(eu,sv); // X=0 横面
        uv[vi+1] = Vector2(su,sv);
        uv[vi+2] = Vector2(su,ev);
        uv[vi+3] = Vector2(eu,ev);
    }
    if( drawflags[3]){
        vi=startvis[3];
        uv[vi+0] = Vector2(su,sv); // X=1 横面
        uv[vi+1] = Vector2(eu,sv);
        uv[vi+2] = Vector2(eu,ev);
        uv[vi+3] = Vector2(su,ev);
    }

    if( drawflags[4]){
        uvs = calcUVs( blockType + (512/16 )*2 );
        su = uvs[0];sv = uvs[1];eu = uvs[2];ev = uvs[3];
        vi=startvis[4];
        uv[vi+0] = Vector2(su,ev); // Y=0　下面
        uv[vi+1] = Vector2(eu,ev);
        uv[vi+2] = Vector2(eu,sv);
        uv[vi+3] = Vector2(su,sv);
    }

    if( drawflags[5]){
        uvs = calcUVs( blockType );
        su = uvs[0];sv = uvs[1];eu = uvs[2];ev = uvs[3];
        vi=startvis[5];
        uv[vi+0] = Vector2(su,sv); // Y=1 上面
        uv[vi+1] = Vector2(eu,sv);
        uv[vi+2] = Vector2(eu,ev);
        uv[vi+3] = Vector2(su,ev);        
    }
    
    // 明るさを決めるための法線
    for(i=0;i<6;i++){
        if( drawflags[i] ){
            vi=startvis[i];
            for(var j=0;j<4;j++){
                normals[vi+j] = Vector3(0,lightIndexToNormal( lights[i*4+j] ),0);
            }
        }
    }

    if(drawflags[0]){
        ti=starttis[0];
        vi=startvis[0];
        triangles[ti+0] = vi+0; // z=0平面の２つの三角
        triangles[ti+1] = vi+2;
        triangles[ti+2] = vi+1;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+3;
        triangles[ti+5] = vi+2;
    }
    if(drawflags[1]){
        ti=starttis[1];
        vi=startvis[1];
        triangles[ti+0] = vi+0; // z=1平面の２つの三角
        triangles[ti+1] = vi+1;
        triangles[ti+2] = vi+2;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+2;
        triangles[ti+5] = vi+3;
    }
    if(drawflags[2]){
        ti=starttis[2];
        vi=startvis[2];
        triangles[ti+0] = vi+0; // x=0
        triangles[ti+1] = vi+1;
        triangles[ti+2] = vi+2;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+2;
        triangles[ti+5] = vi+3;
    }
    if(drawflags[3]){
        ti=starttis[3];
        vi=startvis[3];
        triangles[ti+0] = vi+0; // x=1
        triangles[ti+1] = vi+2;
        triangles[ti+2] = vi+1;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+3;
        triangles[ti+5] = vi+2;
    }
    if(drawflags[4]){
        ti=starttis[4];
        vi=startvis[4];
        triangles[ti+0] = vi+0; // y=0
        triangles[ti+1] = vi+1;
        triangles[ti+2] = vi+2;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+2;
        triangles[ti+5] = vi+3;
    }
    if(drawflags[5]){
        ti=starttis[5];
        vi=startvis[5];
        triangles[ti+0] = vi+0; // y=1
        triangles[ti+1] = vi+2;
        triangles[ti+2] = vi+1;
        triangles[ti+3] = vi+0;
        triangles[ti+4] = vi+3;
        triangles[ti+5] = vi+2;
    }        
}



function Start() {

	if (material)
		renderer.material = material;
	else
		renderer.material.color = Color.white;


    
}

function Update() {
    //    print("objmode:"+objmode);
}

// 0~(sz+2)まで
function toLightIndex(x,y,z,sz) {
    return y*sz*sz+z*sz+x;
}


// 地形データをセットする(xyzならび)
// blocks: AIRとかSTONEとか
// lights: あかるさ0~7 (sz+2)^3 のサイズが必要。
function SetField( blocks: int[], lights:int[], sz:int ) {


    
    if( blocks.length != sz*sz*sz ) throw "invalid block cnt:"+blocks.length.ToString() + " sz:"+sz;
    if( lights.length != (sz+2)*(sz+2)*(sz+2) ) throw "invalid light cnt:"+lights.length.ToString() + " sz:"+sz;
	var mesh : Mesh = GetComponent(MeshFilter).mesh;

    mesh.Clear();

    var vertices : Vector3[] = new Vector3[ sz*sz*sz *24 ];
    var uv : Vector2[] = new Vector2[ sz*sz*sz *24 ];
    var triangles : int[] = new int[ sz*sz*sz * 36 ];
    var normals : Vector3[] = new Vector3[sz*sz*sz*24]; // 頂点数と同じだけ必要
    
    var vi:int=0;
    var ti:int=0;
    

    var makeNum=0;
    var skipNum=0;

    var lts:int[] = new int[6*4]; // Z=0 Z=1 X=0 X=1 Y=0 Y=1 の順
    var drawflags:int[] = new int[6]; // 各面を描画するかどうかのフラグ
    
    for( var y:int = 0; y < sz; y++ ){
        for( var z:int = 0; z < sz; z++ ){
            for( var x:int = 0; x < sz; x++ ){

                var i : int = blocks[x+z*sz+y*sz*sz] ;
                var lx=x+1; // light配列の中は１づつずれている
                var ly=y+1;
                var lz=z+1;                
                if( i > 0 && i <100 && objmode==0){

                    // 周囲をみて完全に埋まってるのはキューブ作ること自体しない
                    if( lights[ toLightIndex(lx-1,ly,lz,sz+2)]==0
                        && lights[ toLightIndex(lx,ly-1,lz,sz+2)]==0
                        && lights[ toLightIndex(lx,ly,lz-1,sz+2)]==0
                        && lights[ toLightIndex(lx+1,ly,lz,sz+2)]==0
                        && lights[ toLightIndex(lx,ly+1,lz,sz+2)]==0
                        && lights[ toLightIndex(lx,ly,lz+1,sz+2)]==0 ){
                        skipNum++;
                        continue;
                    }

                    
                    makeNum++;  
                    // normalは２４個で、面あたり角で３個。
                    // 下にあればあるほど暗い
                    // light配列で-1ならその位置にブロックがあるということ 0以上１５以下なら空間で、光。

                    // z=0の面
                    lts[0]=lts[1]=lts[2]=lts[3]=lights[ toLightIndex(lx,ly,lz-1,sz+2) ];
                    if( lts[0]!=0 )drawflags[0]=1; else drawflags[0]=0;
                    // 0:z=0,0の角 
                    if( lights[toLightIndex(lx,ly-1,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz-1,sz+2)]==0) lts[0]-=2;
                    if( lights[toLightIndex(lx-1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz-1,sz+2)]==0) lts[0]-=2;
                    // z=0,1の角
                    if( lights[toLightIndex(lx,ly-1,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz-1,sz+2)]==0) lts[1]-=2;
                    if( lights[toLightIndex(lx+1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz-1,sz+2)]==0) lts[1]-=2;
                    // z=0,2の角
                    if( lights[toLightIndex(lx+1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[2]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[2]-=2;
                    // z=0,3の角
                    if( lights[toLightIndex(lx-1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[3]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[3]-=2;
                    
                    // z=1の面
                    lts[4]=lts[5]=lts[6]=lts[7]=lights[ toLightIndex(lx,ly,lz+1,sz+2) ];
                    if( lts[4]!=-1 )drawflags[1]=1; else drawflags[1]=0;                    
                    // z=1,4の角
                    if( lights[toLightIndex(lx-1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz+1,sz+2)]==0) lts[4]-=2;
                    if( lights[toLightIndex(lx,ly-1,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz+1,sz+2)]==0) lts[4]-=2;
                    // z=1,5の角
                    if( lights[toLightIndex(lx+1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz+1,sz+2)]==0) lts[5]-=2;
                    if( lights[toLightIndex(lx,ly-1,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz+1,sz+2)]==0) lts[5]-=2;
                    // z=1,6の角
                    if( lights[toLightIndex(lx+1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[6]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[6]-=2;
                    // z=1,7の角
                    if( lights[toLightIndex(lx-1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[7]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[7]-=2;

                    // x=0の面
                    lts[8]=lts[9]=lts[10]=lts[11]=lights[toLightIndex(lx-1,ly,lz,sz+2)];
                    if( lts[8]!=-1 )drawflags[2]=1; else drawflags[2]=0;
                    // x=0,0の角
                    if( lights[toLightIndex(lx-1,ly-1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz-1,sz+2)]==0) lts[8]-=2;
                    if( lights[toLightIndex(lx-1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz-1,sz+2)]==0) lts[8]-=2;
                    // x=0,4の角
                    if( lights[toLightIndex(lx-1,ly-1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz+1,sz+2)]==0) lts[9]-=2;
                    if( lights[toLightIndex(lx-1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly-1,lz+1,sz+2)]==0) lts[9]-=2;
                    // x=0,7の角
                    if( lights[toLightIndex(lx-1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[10]-=2;
                    if( lights[toLightIndex(lx-1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[10]-=2;
                    // x=0,3の角
                    if( lights[toLightIndex(lx-1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[11]-=2;
                    if( lights[toLightIndex(lx-1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[11]-=2;

                    // x=1の面
                    lts[12]=lts[13]=lts[14]=lts[15]=lights[toLightIndex(lx+1,ly,lz,sz+2)];
                    if( lts[12]!=-1 )drawflags[3]=1; else drawflags[3]=0;
                    // x=1,1の角
                    if( lights[toLightIndex(lx+1,ly-1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz-1,sz+2)]==0) lts[12]-=2;
                    if( lights[toLightIndex(lx+1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz-1,sz+2)]==0) lts[12]-=2;
                    // x=1,5の角
                    if( lights[toLightIndex(lx+1,ly-1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz+1,sz+2)]==0) lts[13]-=2;
                    if( lights[toLightIndex(lx+1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly-1,lz+1,sz+2)]==0) lts[13]-=2;
                    // x=1,6の角
                    if( lights[toLightIndex(lx+1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[14]-=2;
                    if( lights[toLightIndex(lx+1,ly,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[14]-=2;
                    // x=1,2の角
                    if( lights[toLightIndex(lx+1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[15]-=2;
                    if( lights[toLightIndex(lx+1,ly,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[15]-=2;

                    // y=0の面
                    lts[16]=lts[17]=lts[18]=lts[19]=lights[toLightIndex(lx,ly-1,lz,sz+2)];
                    if( lts[16]!=-1 )drawflags[4]=1; else drawflags[4]=0;                    
                    // y=0,0の角
                    if( lights[toLightIndex(lx-1,ly-1,lz,sz+2)]==0) lts[16]-=2;
                    if( lights[toLightIndex(lx,ly-1,lz-1,sz+2)]==0) lts[16]-=2;
                    // y=0,1の角
                    if( lights[toLightIndex(lx+1,ly-1,lz,sz+2)]==0) lts[17]-=2;
                    if( lights[toLightIndex(lx,ly-1,lz-1,sz+2)]==0) lts[17]-=2;
                    // y=0,5の角
                    if( lights[toLightIndex(lx+1,ly-1,lz,sz+2)]==0) lts[18]-=2;
                    if( lights[toLightIndex(lx,ly-1,lz+1,sz+2)]==0) lts[18]-=2;
                    // y=0,4の角
                    if( lights[toLightIndex(lx,ly-1,lz+1,sz+2)]==0) lts[19]-=2;
                    if( lights[toLightIndex(lx-1,ly-1,lz,sz+2)]==0) lts[19]-=2;

                    // y=1の面
                    lts[20]=lts[21]=lts[22]=lts[23]=lights[toLightIndex(lx,ly+1,lz,sz+2)];
                    if( lts[20]!=-1 )drawflags[5]=1; else drawflags[5]=0;
                    // y=1,3の角
                    if( lights[toLightIndex(lx-1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[20]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz-1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz-1,sz+2)]==0) lts[20]-=2;
                    // y=1,2の角
                    if( lights[toLightIndex(lx,ly+1,lz-1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[21]-=2;
                    if( lights[toLightIndex(lx+1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz-1,sz+2)]==0) lts[21]-=2;
                    // y=1,6の角
                    if( lights[toLightIndex(lx+1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[22]-=2;
                    if( lights[toLightIndex(lx,ly+1,lz+1,sz+2)]==0 && lights[toLightIndex(lx+1,ly+1,lz+1,sz+2)]==0) lts[22]-=2;
                    // y=1,7の角
                    if( lights[toLightIndex(lx,ly+1,lz+1,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[23]-=2;
                    if( lights[toLightIndex(lx-1,ly+1,lz,sz+2)]==0 && lights[toLightIndex(lx-1,ly+1,lz+1,sz+2)]==0) lts[23]-=2;
                    
                    makeCube( Vector3(x,y,z),
                              vertices,
                              uv,
                              normals,
                              vi,
                              triangles,
                              ti,
                              i,
                              lts,
                              drawflags );
                    vi += 24;
                    ti += 36;
                } else if( (i==REDFLOWER||i==BLUEFLOWER ) && objmode==1 ){
                    // 花とか
                    makeFlowerObj( Vector3(x,y,z),
                                   vertices,
                                   uv,
                                   normals,
                                   vi,
                                   triangles,
                                   ti,
                                   i,
                                   lights[toLightIndex(lx,ly,lz,sz+2)] );
                    vi += 8;
                    ti += 24;
                }
            }
        }
    }
    
    mesh.vertices = vertices;
    mesh.uv = uv;
    mesh.triangles = triangles;
    mesh.normals = normals;
    //    mesh.RecalculateNormals();


    
}

