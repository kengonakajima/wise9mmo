
var headTextPrefab : GameObject;

var pitch : float;
var yaw : float;

var dy : float;

var heroSpeed : float;

var nose : Vector3; // こういう風に関数の外に変数定義するとGUIで見える
var falling = false;
var needSend = false;


var clientID = -1; // サーバ内のid


var lastInterval : float;



function Start () {
    pitch = 0;
    dy = 0;

}

var hVel=0.0;
var vVel=0.0;

function Move( dpitch:float, dyaw:float, h:float, v:float ) {
    yaw += dyaw;
    pitch += dpitch;
    hVel = h;
    vVel = v;
}

var gotoPos : Vector3;
var gotoTime : float;
var gotoDiffTime : float;
var gotoOrigPos : Vector3;

function SetMove( pt, yw, pos, _dy, flng, dt ) {
    print( "setmove:" + pos);
    yaw = yw;
    pitch = pt;
    gotoPos = pos;
	gotoTime = Time.realtimeSinceStartup + dt;	
	gotoDiffTime = dt;	
	gotoOrigPos = transform.position;
    if( !falling && flng ){
    	dy = _dy;
		falling = true;
	}
}


function Update () {

//    print( "cliid:"+ clientID + " name:" + name );
    
    var dTime = Time.realtimeSinceStartup - lastInterval;
    lastInterval = Time.realtimeSinceStartup;

    var dnose : Vector3;
    var dside : Vector3;
    
    dnose.x = 1.0 * Mathf.Cos(pitch);
    dnose.y = yaw;
    dnose.z = 1.0 * Mathf.Sin(pitch);
    dside.x = 1.0 * Mathf.Cos(pitch - Mathf.PI/2);
    dside.y = 0;
    dside.z = 1.0 * Mathf.Sin(pitch - Mathf.PI/2);


    nose = transform.position + dnose ;
    transform.LookAt( nose );
    
    var dtr : Vector3;
    dtr = dnose * vVel/4 + dside * hVel/4;

    vVel = hVel = 0;

    if(falling){
        //        print( "dy:"+ (0.01 * dTime * heroSpeed ) + ":" + dTime + " hs:" + heroSpeed );
        dy -= 0.01 * dTime * heroSpeed;
    }
    
    // 絶対的な世界の底
    if( transform.position.y < 0 ){
        transform.position.y = 0;
        dy = 0;
        falling = false;
    }

    dtr.y = dy;

    var nextpos = transform.position + dtr * dTime * heroSpeed;
    
    //地形判定
    var com = GameObject.Find("CommunicatorCube");
    var cs = com.GetComponent("CommunicatorScript");    
    var blk = cs.getBlock( nextpos.x, nextpos.y-1, nextpos.z);
    if(blk!=null){
        if( blk == cs.STONE|| blk == cs.WATER ){

                print( "hit:"+blk);
            var iy:int = nextpos.y;
            nextpos.y = iy+1;
            falling = false;
            dy=0;
            //            print( "set:"
        } else {
            falling=true;
        }
        
    }

    transform.position = nextpos;

	if( gotoTime > Time.realtimeSinceStartup ) {
		var v : Vector3;
		var dv = gotoPos - gotoOrigPos;
		var rate = ( gotoTime - Time.realtimeSinceStartup ) / gotoDiffTime;
		var nextv = gotoOrigPos + dv * (1.0-rate);
		transform.position.x = nextv.x;
		transform.position.z = nextv.z; 
	}

}




function OnGUI () {
    var c = GameObject.Find( "Main Camera");
    var v: Vector3 = c.camera.WorldToScreenPoint(transform.position);

    if( clientID != -1 &&  v.x>0&&v.y>0&&v.z > 1.0 ){
//        print("t:" + v.x + "," + v.y + "," + v.z );        
        GUI.Label( Rect( v.x, Screen.height-v.y  - 50, 100,50 ), ""+clientID);
    }
    
    
}

    






