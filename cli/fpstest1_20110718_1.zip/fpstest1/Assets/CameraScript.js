var hero : GameObject;
var hs;



function Start () {
    hero = GameObject.Find( "HeroCube" );
    hs = hero.GetComponent("HeroScript");
    
}



function Update () {
    
    

    
}
