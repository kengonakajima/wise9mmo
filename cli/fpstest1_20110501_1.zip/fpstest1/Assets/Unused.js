/*
    var nt;
    var s : int;
    var t : int;
    if( Input.GetButtonDown( "Fire1" ) ) {

        tmpcounter0 +=1;
        for(t = 0;t<16;t++){
            for(s = 0; s<16; s++){
                var cu = Instantiate( prefabVoxel, Vector3( t*1.2 , tmpcounter0 *1.2, s*1.2 ), Quaternion.identity );
                cubes.Push(cu);
            }
        }
        setStat(tmpcounter0*16*16);

    }
    if( Input.GetButtonDown( "Fire2" ) ){
        tmpcounter1 +=  1;
        for(t = 0;t<8;t++){
            for(s = 0; s<8; s++){
                cu = Instantiate( prefabMulti, Vector3( t*16, tmpcounter1 *16, s*16 ), Quaternion.identity );
                cubes.Push(cu);
            }
        }
        setStat(tmpcounter1*8*8* 8*8*8 );
    }
    if( Input.GetButtonDown( "Fire3" ) ){
        var yy : int = tmpcounter2 / 16;
        var zz : int = ( tmpcounter2 % 16 ) / 4;
        var xx : int = ( tmpcounter2 % 4 ) ;

        
        for(t = 0;t<6;t++){
            for(s = 0; s<6; s++){
                cu = Instantiate( prefabProcedural, Vector3( xx*6*10+s*10, yy *10, zz*6*10+t*10 ), Quaternion.identity );                
                cubes.Push(cu);
            }
        }
        tmpcounter2 += 1;        
        setStat(tmpcounter2*6*6* 4*4*4 );
    }
/////////////////////////////////////////////////////////////////////////////////

function clearCubes() {

    for( var c in cubes ) {
        Destroy(c);
    }
    
    cubes = new Array();
    tmpcounter0 = tmpcounter1 = tmpcounter2 = 0;
    setStat(0);

    // FBXビューワー
	var mesh : Mesh = GetComponent(MeshFilter).mesh;
    var ii : int;
    for( ii  = 0; ii < mesh.vertices.length ; ii ++ ) {
        print( "v["+ii+"]:" + mesh.vertices[ii] );
    }
    for( ii = 0; ii < mesh.uv.length; ii ++ ){
        print( "uv["+ii+"]:" + mesh.uv[ii] );
    }
    
}
*/
