

var protocol;
var rpcfunctions={};
var myClientID=0;

function addRPC(name,f){
    rpcfunctions[name]=f;
}

function escape(s){
    return s.Replace( '"', "\\\"" ).Replace( "'", "\\'" );
}

function toString(x) : String {
    var out;

    var s  = typeof(x).ToString();
    
    switch(s){
    case "System.String":
        out= "\"" + escape(x) + "\"";
        break;
    case "System.Int32":
        out= ""+x;
        break;
    case "System.Single":
        out= ""+parseInt(x*1000);
        break;
    case "System.Int32[]":
        out=arrayToJson(x);
        break;
    case "System.String[]":
        out=arrayToJson(x);
        break;
    case "System.Single[]":
        out=arrayToJson(x);
        break;
    case "Boo.Lang.Hash":
        out=hashToJson(x);
        break;
    case "System.Object[]":
        out=objaryToJson(x);
        break;
    case "System.Boolean":
        if(x) out= "1"; else out="0";
        break;
        
    default:
        throw "not implemented:"+typeof(x);        
    }
    return out;
}

function hashToJson(h) {
    var out = new Array();
    for( key in h.Keys ){
        out.push( "\""+key+"\":" + toString(h[key]) );
    }
    return "{"+out.Join(",")+"}";
}
function objaryToJson(oa) {
    var out = new Array();
    for( o in oa ) {
        out.push( toString(o));
    }
    return "["+out.Join(",")+"]";
}

function arrayToJson(ary) : String {
    var out = new Array();
    for(var i=0;i<ary.length;i++){
        out.push( toString(ary[i]) );
    }
    return "["+out.Join(",")+"]";
}

function send( meth ){ sendWithParams( meth, [] ); }
function send( meth, arg0 ){ sendWithParams( meth, [ arg0 ] ); }
function send( meth, arg0, arg1 ){ sendWithParams( meth, [ arg0, arg1 ] );}
function send( meth, arg0, arg1, arg2 ){ sendWithParams( meth, [ arg0, arg1, arg2 ] );}
function send( meth, arg0, arg1, arg2, arg3 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3 ] );}
function send( meth, arg0, arg1, arg2, arg3, arg4 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3, arg4 ] );}
function send( meth, arg0, arg1, arg2, arg3, arg4, arg5 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3, arg4, arg5 ] );}
function send( meth, arg0, arg1, arg2, arg3, arg4, arg5, arg6 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3, arg4, arg5, arg6 ] );}
function send( meth, arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7 ] );}
function send( meth, arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8 ){ sendWithParams( meth, [ arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8 ] );}

function sendWithParams(meth, params ){
    var h={};
    h["method"]=meth;
    h["params"]=params;
    protocol.writeSocket( hashToJson(h));
}



function ensurePC( id:int, pos:Vector3 ){
    var pc;
    var name = "guest_" + id;
    pc = GameObject.Find(name);
    if(!pc){
        pc = Instantiate( prefabGuest, pos,  Quaternion.identity );
        pc.name = name;
        var hs = pc.GetComponent( "HeroScript" );
        print( "hs:"+typeof(hs));
        hs.clientID = id;
    }
    return pc;
}

function rpcLoginResult( cliID ) {
    print( "rpcLoginResult:" +cliID );
	myClientID = cliID;

    var hero = GameObject.Find( "HeroCube" );
    var hs = hero.GetComponent("HeroScript" );
    hs.clientID = myClientID;
}

function rpcMoveNotify( cliID, x,y,z, pitch, yaw, dy, jm, dt ){

//    print( "id:"+cliID+" dt:" +dt  );

    // idからpcを検索

    var pos:Vector3 = Vector3( x/1000.0, y/1000.0, z/1000.0 );
    var pc = ensurePC( cliID, pos );

    var hs = pc.GetComponent( "HeroScript");
    hs.SetMove( pitch, yaw, pos, dy/1000.0, jm, dt/1000.0 );

    
}



// 通信をするobj
function Start () {
    cubes = new Array();

    protocol = GetComponent( "ProtocolScript");
    addRPC( "loginResult", rpcLoginResult );
    addRPC( "moveNotify", rpcMoveNotify );
    
}





///　大量の立方体関連


var cubes : Array;
function setStat( n:int ){
    nt = statText.GetComponent( "GUIText" );
    nt.text = (n).ToString() + " cubes";
}


function doProtocol() {

    // 受信
    var h = protocol.readJSON();
    if( h != null ){

//		print( "data from server:"+h )        ;
        var f = rpcfunctions[ h["method"].str ];
//        print( "from server:'"+h["method"].str+"' , len:" + h["params"].list.Count );
		var args = h["params"].list;
        var ra = new Array();
        for( var i=0;i<args.Count;i++){
            if( args[i] == null ){continue;}

            switch( args[i].type ){
            case 0: //NULL
                ra[i] = null;
                break;
            case 1: // string
                ra[i] = args[i].str;
                break;
            case 2: // number
                ra[i] = args[i].n;
                break;
            case 3: // object
                ra[i] = null;
                print( "json objval: not implemented" );
                break;
            case 4: // array
                ra[i] = null;
                print( "json arrayval: not implemented" );                
                break;
            case 5: // bool
                ra[i] = args[i].b;
                break;
            default:
                ra[i] = null;
                print( "json unknownval: not implemented" );
                break;
            } 
        }
        
		switch( args.Count ){
		case 0:	f(); break;
		case 1: f( ra[0] ); break;
		case 2: f( ra[0], ra[1] ); break;
		case 3: f( ra[0], ra[1], ra[2] ); break;
		case 4: f( ra[0], ra[1], ra[2], ra[3] ); break;
		case 5: f( ra[0], ra[1], ra[2], ra[3], ra[4] ); break;
		case 6: f( ra[0], ra[1], ra[2], ra[3], ra[4], ra[5] ); break;
		case 7: f( ra[0], ra[1], ra[2], ra[3], ra[4], ra[5], ra[6] ); break;
		case 8: f( ra[0], ra[1], ra[2], ra[3], ra[4], ra[5], ra[6], ra[7] ); break;
		case 9: f( ra[0], ra[1], ra[2], ra[3], ra[4], ra[5], ra[6], ra[7], ra[8] ); break;
        default: throw "too many args from server"; 
		}
    }
    
    if( protocol.isReady() && loginSent == false){
        loginSent = true;
        send( "login" );
    }
/*
    var fn = f;
    var x = fn(1,2,3,4,5);
    print( "x:" + x );

    anyarg(1);
    anyarg(1,"a");
*/    

        

    // 送信

    // 現在の状態を送る
    var hero = GameObject.Find( "HeroCube" );
    var hs = hero.GetComponent("HeroScript" );
//    print( "hero:"+typeof(hero) + " hs:" + typeof(hs) );    
    var t = Time.realtimeSinceStartup;
    if(  t > ( protocolLastSent + 0.2 ) || hs.needSend ){
        send( "move",
              hero.transform.position.x,
              hero.transform.position.y,
              hero.transform.position.z,
              hs.pitch,
              hs.yaw,
              hs.dy,
              hs.jumping,
              t - protocolLastSent
            );
        protocolLastSent = t;
		hs.needSend = false;
    }

}


var protocolLastSent=0.0;
var loginSent=false;

var tmpcounter0 = 0;
var tmpcounter1 = 0;
var tmpcounter2 = 0;

var statText : GUIText;


var prefabGuest : GameObject;

function Update () {
    doProtocol();
    
}

function OnGUI() {
    if( GUI.Button( Rect( 200,40,80,20), "Send" )) {
        var psend  = GetComponent( "ProtocolScript" );
        psend.writeSocket( "fromjs" );
    }
    if( GUI.Button( Rect( 300,40,80,20), "Recv" )) {
        var precv  = GetComponent( "ProtocolScript" );        
        var s = precv.readSocket();
        if( s != "" ){
            print( "recv string:" + s );
        }
    }
    
    if( GUI.Button( Rect( 20,40,80,20), "Clear" )) {

        send( "sum", 1, 2, "hoge" );
        
    }
}

