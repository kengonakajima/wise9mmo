var hero : GameObject;




function Start () {
    hero = GameObject.Find( "HeroCube" );

/*
        transform.Translate(35,55,0);
        transform.LookAt( hero.transform.position );
*/
}



function Update () {
    var hs = hero.GetComponent("HeroScript");

        transform.LookAt( hs.nose );
        transform.position = hero.transform.position ;
/*
        var dscr = Input.GetAxis( "Mouse ScrollWheel" );
        transform.position += Vector3( 0, dscr*5, 0 );
        transform.LookAt( hs.nose );
*/
    
//    print( "fpsm:" + fpsMode + " campos:" + hero.transform.position.x + "," +hero.transform.position.y + " camnose:" + hs.nose + " campitch:" + hs.pitch );
    
}
