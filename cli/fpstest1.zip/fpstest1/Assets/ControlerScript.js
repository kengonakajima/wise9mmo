// 操作を反映する

var hero : GameObject;
var herosc;
function Start () {
    hero = GameObject.Find( "HeroCube" );
    herosc = hero.GetComponent("HeroScript" );
}

function Update () {
    
    var mx = Input.GetAxis( "Mouse X" );
    var my = Input.GetAxis( "Mouse Y" );

    var h = Input.GetAxis( "Horizontal");
    var v = Input.GetAxis( "Vertical" );    

    herosc.Move( mx / 10 * -1 , my / 10, h, v );

    
    var j = Input.GetButton( "Jump" );
    if(j){
        if( herosc.dy == 0 ){
            herosc.dy = 0.2;
            herosc.jumping = true;
			herosc.needSend = true;
        }
    }

}