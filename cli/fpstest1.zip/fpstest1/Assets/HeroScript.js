
var headTextPrefab : GameObject;

var pitch : float;
var yaw : float;

var dy : float;

var heroSpeed : float;

var nose : Vector3; // こういう風に関数の外に変数定義するとGUIで見える
var jumping = false;
var needSend = false;


var clientID = -1; // サーバ内のid


var lastInterval : float;



function Start () {
    pitch = 0;
    dy = 0;

}

var hVel=0;
var vVel=0;

function Move( dpitch, dyaw, h, v ) {
    yaw += dyaw;
    pitch += dpitch;
    hVel = h;
    vVel = v;
}

var gotoPos : Vector3;
var gotoTime : float;
var gotoDiffTime : float;
var gotoOrigPos : Vector3;

function SetMove( pt, yw, pos, _dy, jm, dt ) {
    print( "setmove:" + pos);
    yaw = yw;
    pitch = pt;
    gotoPos = pos;
	gotoTime = Time.realtimeSinceStartup + dt;	
	gotoDiffTime = dt;	
	gotoOrigPos = transform.position;
    if( !jumping && jm ){
    	dy = _dy;
		jumping = true;
	}
}

function Update () {

//    print( "cliid:"+ clientID + " name:" + name );
    
    var dTime = Time.realtimeSinceStartup - lastInterval;
    lastInterval = Time.realtimeSinceStartup;

    var dnose : Vector3;
    var dside : Vector3;
    
    dnose.x = 1.0 * Mathf.Cos(pitch);
    dnose.y = yaw;
    dnose.z = 1.0 * Mathf.Sin(pitch);
    dside.x = 1.0 * Mathf.Cos(pitch - Mathf.PI/2);
    dside.y = 0;
    dside.z = 1.0 * Mathf.Sin(pitch - Mathf.PI/2);


    nose = transform.position + dnose ;
    transform.LookAt( nose );
    
    var dtr : Vector3;
    dtr = dnose * vVel/4 + dside * hVel/4;

    vVel = hVel = 0;

    if(jumping){
	print( "dy:"+ (0.01 * dTime * heroSpeed ) + ":" + dTime + " hs:" + heroSpeed );
        dy -= 0.01 * dTime * heroSpeed;
    }
    if( transform.position.y < -4 ){
        transform.position.y = -4;
        dy = 0;
        jumping = false;
    }
    
    dtr.y = dy;
    transform.position += dtr * dTime * heroSpeed;

	if( gotoTime > Time.realtimeSinceStartup ) {
		var v : Vector3;
		var dv = gotoPos - gotoOrigPos;
		var rate = ( gotoTime - Time.realtimeSinceStartup ) / gotoDiffTime;
		print("rate:"+rate + " gtt:"+ gotoTime );
		var nextv = gotoOrigPos + dv * (1.0-rate);
		transform.position.x = nextv.x;
		transform.position.z = nextv.z; 
	}

}




function OnGUI () {
    var c = GameObject.Find( "Main Camera");
    var v: Vector3 = c.camera.WorldToScreenPoint(transform.position);

    if( clientID != -1 &&  v.x>0&&v.y>0&&v.z > 1.0 ){
//        print("t:" + v.x + "," + v.y + "," + v.z );        
        GUI.Label( Rect( v.x, Screen.height-v.y  - 50, 100,50 ), ""+clientID);
    }
    
    
}

    






